# UPSC Prelims PYQ Practice

A Chrome/Edge New Tab extension for practicing UPSC CSE Prelims PYQs with instant feedback, explanations, bookmarks, mistakes and local progress tracking.

## Package
Manifest V3. The extension uses only the `storage` permission and the standard New Tab override.

## Local testing
1. Extract this folder.
2. Open `chrome://extensions/` or `edge://extensions/`.
3. Turn on Developer mode.
4. Choose **Load unpacked**.
5. Select this folder.

## Data
Practice history, bookmarks, settings and attempt statistics are stored locally using browser extension storage. No account or browsing-history permission is required by the current build.

## Source material
Question data was prepared from the PDF materials supplied by the project owner for this extension. The project owner states that they created/edited the supplied PDFs and authorizes their use for this project.
