const DEFAULT_STATS = { byId: {}, today: { date: '', answered: 0, correct: 0 } };
const DEFAULT_SETTINGS = { order: 'random', explanation: 'always', shortcuts: true, theme: 'colorful' };
const state = {
  questions: [], current: null, selected: null, submitted: false,
  mode: 'all', year: 'all', subject: 'all', pendingYear: 'all', pendingSubject: 'all',
  queue: [], queueIndex: 0, questionNumber: 0, stats: structuredClone(DEFAULT_STATS), settings: {...DEFAULT_SETTINGS}
};
const els = {};

const $ = id => document.getElementById(id);
async function storageGet() { return chrome.storage.local.get(['stats', 'settings']); }
async function storageSet(v) { return chrome.storage.local.set(v); }
function dateKey() { return new Date().toISOString().slice(0,10); }
function ensureToday() { if (!state.stats.today || state.stats.today.date !== dateKey()) state.stats.today = {date:dateKey(), answered:0, correct:0}; }
function cleanText(s, explanation=false) {
  let t = String(s ?? '').replace(/\r/g,'').replace(/\u00ad/g,'');
  t = t.replace(/(?<=\w)-\s*\n\s*(?=\w)/g,'');
  t = t.replace(/\s*●\s*/g,'\n• ');
  t = t.replace(/\bPW\s+ONLYIAS\s+SUPER\s+HINT\b\s*:?/gi,'Key takeaway:');
  t = t.replace(/\bSub-Theme\s*:\s*/gi,'');
  t = t.replace(/^\s*Answer\s*:\s*[A-D]\s*\n?/i,'');
  t = t.replace(/[ \t]*\n[ \t]*/g,' ');
  t = t.replace(/[ \t]+/g,' ').trim();
  if (!explanation) t = t.replace(/\s+(?=(?:\d{1,2}|[IVX]{1,4})\.\s)/g,'\n');
  else {
    t = t.replace(/\s+(?=Key takeaway:)/g,'\n');
    t = t.replace(/\s*•\s*/g,'\n• ');
  }
  return t.trim();
}
function applyTheme() {
  const t = state.settings.theme;
  const systemDark = t === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches;
  document.body.classList.toggle('dark', t === 'dark' || systemDark);
  document.body.classList.toggle('colorful', t === 'colorful' || (t === 'system' && !systemDark));
}
function normalizeStats() {
  state.stats = state.stats || structuredClone(DEFAULT_STATS);
  state.stats.byId ||= {};
  state.stats.today ||= {date:'',answered:0,correct:0};
  ensureToday();
  for (const q of state.questions) {
    const r = state.stats.byId[q.id];
    if (r) { r.attempts ||= 0; r.correct ||= 0; r.wrongs ||= 0; r.bookmarked = !!r.bookmarked; }
  }
}
function subjectList() { return [...new Set(state.questions.map(q=>q.subject||'General Studies'))].sort((a,b)=>a.localeCompare(b)); }
function populateFilters() {
  const years = [...new Set(state.questions.map(q=>Number(q.year)).filter(Number.isFinite))].sort((a,b)=>b-a);
  for (const y of years) { const o=document.createElement('option'); o.value=String(y); o.textContent=String(y); els.yearFilter.appendChild(o); }
  for (const s of subjectList()) { const o=document.createElement('option'); o.value=s; o.textContent=s; els.subjectFilter.appendChild(o); }
  els.yearFilter.value=state.year; els.subjectFilter.value=state.subject;
}
function matchesFilters(q) {
  if (state.year !== 'all' && String(q.year)!==state.year) return false;
  if (state.subject !== 'all' && (q.subject||'General Studies')!==state.subject) return false;
  if (state.mode==='mistakes' && !(state.stats.byId[q.id]?.wrongs>0)) return false;
  if (state.mode==='bookmarks' && !state.stats.byId[q.id]?.bookmarked) return false;
  return true;
}
function buildQueue() {
  let pool=state.questions.filter(matchesFilters);
  if (!pool.length) { state.queue=[]; return; }
  if (state.settings.order==='sequential') {
    pool.sort((a,b)=>Number(b.year)-Number(a.year) || Number(a.question_no)-Number(b.question_no) || a.id.localeCompare(b.id));
  } else {
    // Stable random shuffle for the current new-tab session.
    for (let i=pool.length-1;i>0;i--) { const j=Math.floor(Math.random()*(i+1)); [pool[i],pool[j]]=[pool[j],pool[i]]; }
  }
  state.queue=pool;
  state.queueIndex=Math.min(state.queueIndex, Math.max(0,pool.length-1));
}
function nextQuestion() {
  if (!state.queue.length) { renderEmpty(true); return; }
  if (state.settings.order==='sequential') {
    if (state.queueIndex >= state.queue.length) state.queueIndex=0;
    state.current=state.queue[state.queueIndex++];
  } else {
    if (state.queue.length===1) state.current=state.queue[0];
    else { let next=state.current; while (next===state.current) next=state.queue[Math.floor(Math.random()*state.queue.length)]; state.current=next; }
  }
  state.selected=null; state.submitted=false; state.questionNumber+=1; renderQuestion();
}
function renderEmpty(show) { els.empty.hidden=!show; els.practice.hidden=show; }
function renderQuestion() {
  const q=state.current; if(!q) return;
  renderEmpty(false); els.loading.hidden=true; els.practice.hidden=false;
  els.feedback.hidden=true; els.nextBtn.hidden=true; els.submitBtn.hidden=false; els.submitBtn.disabled=true;
  els.sessionCount.textContent=`Question ${state.questionNumber}`;
  els.yearBadge.textContent=q.year??'—'; els.subjectBadge.textContent=q.subject||'General Studies'; els.sourceBadge.textContent=q.source||'PYQ';
  els.questionText.textContent=cleanText(q.question, false);
  els.options.innerHTML='';
  q.options.forEach((text,i)=>{
    const b=document.createElement('button'); b.className='option'; b.dataset.index=String(i); b.innerHTML=`<span class="option-letter">${String.fromCharCode(65+i)}</span><span class="option-text"></span>`;
    b.querySelector('.option-text').textContent=cleanText(text, false).replace(/\n/g,' '); b.addEventListener('click',()=>selectOption(i)); els.options.appendChild(b);
  });
  const saved=!!state.stats.byId[q.id]?.bookmarked; els.bookmarkBtn.classList.toggle('saved',saved); els.bookmarkBtn.textContent=saved?'★':'☆';
  updateUI();
}
function selectOption(i) {
  if(state.submitted) return; state.selected=i;
  [...els.options.children].forEach((b,idx)=>b.classList.toggle('selected',idx===i)); els.submitBtn.disabled=false;
}
async function submitAnswer() {
  if(state.selected===null||state.submitted||!state.current) return;
  state.submitted=true; const q=state.current; const correct=state.selected===q.answer;
  const r=state.stats.byId[q.id] ||= {attempts:0,correct:0,wrongs:0,bookmarked:false};
  r.attempts++; if(correct) r.correct++; else r.wrongs++; ensureToday(); state.stats.today.answered++; if(correct) state.stats.today.correct++;
  await storageSet({stats:state.stats});
  [...els.options.children].forEach((b,i)=>{b.disabled=true;b.classList.remove('selected');if(i===q.answer)b.classList.add('correct');if(i===state.selected&&i!==q.answer)b.classList.add('wrong');});
  els.feedback.hidden=false; els.feedbackTitle.textContent=correct?'✓ Correct':'✗ Incorrect'; els.feedbackTitle.className=`feedback-title ${correct?'correct':'wrong'}`;
  els.feedbackAnswer.textContent=`Correct answer: ${String.fromCharCode(65+q.answer)}`;
  const showExp=state.settings.explanation==='always'||!correct; els.explanationLabel.hidden=!showExp; els.explanation.hidden=!showExp;
  els.explanation.textContent=cleanText(q.explanation||'Explanation was not available in the supplied source for this question.', true);
  els.submitBtn.hidden=true; els.nextBtn.hidden=false; updateUI();
}
async function toggleBookmark() {
  if(!state.current)return; const r=state.stats.byId[state.current.id] ||= {attempts:0,correct:0,wrongs:0,bookmarked:false}; r.bookmarked=!r.bookmarked; await storageSet({stats:state.stats}); renderQuestion();
}
function updateUI() {
  ensureToday(); const a=state.stats.today.answered,c=state.stats.today.correct; const accuracy=a?`${Math.round(c/a*100)}%`:'—';
  els.todayCount.textContent=a; els.todayAccuracy.textContent=accuracy; els.answeredToday.textContent=a; els.correctToday.textContent=c; els.bankCount.textContent=state.questions.length.toLocaleString('en-IN');
  els.activeFilters.textContent=`${state.year==='all'?'All years':state.year} · ${state.subject==='all'?'All subjects':state.subject}`;
  const totalAttempts=Object.values(state.stats.byId).reduce((s,r)=>s+(r.attempts||0),0); const mistakes=Object.values(state.stats.byId).filter(r=>(r.wrongs||0)>0).length; const bookmarks=Object.values(state.stats.byId).filter(r=>r.bookmarked).length;
  els.statAttempted.textContent=a; els.statCorrect.textContent=c; els.statAccuracy.textContent=accuracy; els.statMistakes.textContent=mistakes; els.statBookmarks.textContent=bookmarks; els.statTotalAttempts.textContent=totalAttempts;
  els.shortcutHint.hidden=!state.settings.shortcuts;
}
function setMode(mode) { state.mode=mode; ['allBtn','mistakesBtn','bookmarksBtn'].forEach(id=>els[id].classList.remove('active')); els[mode==='all'?'allBtn':mode==='mistakes'?'mistakesBtn':'bookmarksBtn'].classList.add('active'); restartSession(); }
function restartSession() { state.questionNumber=0; state.queueIndex=0; state.current=null; buildQueue(); nextQuestion(); }
function openPanel(id) { $(id).hidden=false; }
function closePanel(id) { $(id).hidden=true; }
function clearFilters() { state.year='all';state.subject='all';state.pendingYear='all';state.pendingSubject='all';els.yearFilter.value='all';els.subjectFilter.value='all';restartSession();updateUI(); }
async function resetAll() { if(!confirm('Reset all UPSC extension progress on this device? This cannot be undone.'))return; state.stats=structuredClone(DEFAULT_STATS); normalizeStats(); await storageSet({stats:state.stats}); restartSession(); updateUI(); closePanel('settingsPanel'); }
async function resetToday() { if(!confirm('Reset today\'s attempt and accuracy counters?'))return; state.stats.today={date:dateKey(),answered:0,correct:0}; await storageSet({stats:state.stats}); updateUI(); }
function populateSettings() { els.orderSetting.value=state.settings.order; els.explanationSetting.value=state.settings.explanation; els.shortcutSetting.checked=state.settings.shortcuts; els.themeSetting.value=state.settings.theme; }
async function saveSettings() {
  state.settings={order:els.orderSetting.value, explanation:els.explanationSetting.value, shortcuts:els.shortcutSetting.checked, theme:els.themeSetting.value};
  await storageSet({settings:state.settings}); applyTheme(); buildQueue(); restartSession();
}
async function init() {
  Object.assign(els, {
    loading:$('loading'), practice:$('practice'), empty:$('empty'), yearFilter:$('yearFilter'), subjectFilter:$('subjectFilter'),
    allBtn:$('allBtn'), mistakesBtn:$('mistakesBtn'), bookmarksBtn:$('bookmarksBtn'), todayCount:$('todayCount'), todayAccuracy:$('todayAccuracy'),
    yearBadge:$('yearBadge'), subjectBadge:$('subjectBadge'), sourceBadge:$('sourceBadge'), sessionCount:$('sessionCount'), questionText:$('questionText'), options:$('options'),
    submitBtn:$('submitBtn'), nextBtn:$('nextBtn'), feedback:$('feedback'), feedbackTitle:$('feedbackTitle'), feedbackAnswer:$('feedbackAnswer'),
    explanationLabel:$('explanationLabel'), explanation:$('explanation'), bankCount:$('bankCount'), answeredToday:$('answeredToday'), correctToday:$('correctToday'),
    bookmarkBtn:$('bookmarkBtn'), activeFilters:$('activeFilters'), shortcutHint:$('shortcutHint'), statAttempted:$('statAttempted'), statCorrect:$('statCorrect'), statAccuracy:$('statAccuracy'), statMistakes:$('statMistakes'), statBookmarks:$('statBookmarks'), statTotalAttempts:$('statTotalAttempts'),
    orderSetting:$('orderSetting'), explanationSetting:$('explanationSetting'), shortcutSetting:$('shortcutSetting'), themeSetting:$('themeSetting')
  });
  try {
    state.questions=await fetch('data/questions.json').then(r=>r.json());
    const stored=await storageGet(); state.stats=stored.stats||structuredClone(DEFAULT_STATS); state.settings={...DEFAULT_SETTINGS,...(stored.settings||{})}; normalizeStats(); populateFilters(); populateSettings(); applyTheme();
    updateUI(); restartSession();
  } catch(e) { console.error(e); els.loading.textContent='Could not load the PYQ bank. Reload the extension from chrome://extensions/.'; return; }
  els.allBtn.addEventListener('click',()=>setMode('all')); els.mistakesBtn.addEventListener('click',()=>setMode('mistakes')); els.bookmarksBtn.addEventListener('click',()=>setMode('bookmarks'));
  $('filterBtn').addEventListener('click',()=>{els.yearFilter.value=state.year;els.subjectFilter.value=state.subject;openPanel('filterPanel');});
  $('settingsBtn').addEventListener('click',()=>openPanel('settingsPanel')); $('statsBtn').addEventListener('click',()=>{updateUI();openPanel('statsPanel');});
  $('applyFilter').addEventListener('click',()=>{state.year=els.yearFilter.value;state.subject=els.subjectFilter.value;closePanel('filterPanel');restartSession();updateUI();});
  $('clearFilterPanel').addEventListener('click',clearFilters); $('clearFiltersBtn').addEventListener('click',clearFilters);
  els.submitBtn.addEventListener('click',submitAnswer); els.nextBtn.addEventListener('click',nextQuestion); els.bookmarkBtn.addEventListener('click',toggleBookmark);
  els.orderSetting.addEventListener('change',saveSettings); els.explanationSetting.addEventListener('change',saveSettings); els.shortcutSetting.addEventListener('change',saveSettings); els.themeSetting.addEventListener('change',saveSettings);
  $('resetAllBtn').addEventListener('click',resetAll); $('resetTodayBtn').addEventListener('click',resetToday);
  document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>closePanel(b.dataset.close)));
  document.querySelectorAll('.overlay').forEach(o=>o.addEventListener('click',e=>{if(e.target===o)closePanel(o.id);}));
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape'){ for(const id of ['filterPanel','settingsPanel','statsPanel']) closePanel(id); return; }
    if(!state.settings.shortcuts||e.ctrlKey||e.metaKey||e.altKey)return;
    const active=document.activeElement?.tagName; if(active==='INPUT'||active==='SELECT'||active==='TEXTAREA')return;
    if(state.submitted&&e.key==='Enter'){e.preventDefault();nextQuestion();return;} if(state.submitted)return;
    const k=e.key.toLowerCase(); if('abcd'.includes(k)){selectOption(k.charCodeAt(0)-97);e.preventDefault();} if(e.key==='Enter'){submitAnswer();e.preventDefault();}
  });
  if(window.matchMedia) window.matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change',applyTheme);
}
init();
